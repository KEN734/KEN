const help1 = (prefix) => {

	return `
╔══✪〘 𝗠𝗘𝗡𝗨 𝗚𝗘𝗥𝗔𝗟 〙
║ 
╠➥ *${prefix}add
╠➥ *${prefix}addemote
╠➥ *${prefix}akeno
╠➥ *${prefix}belle
╠➥ *${prefix}belle1
╠➥ *${prefix}belle2
╠➥ *${prefix}belle3
╠➥ *${prefix}blocklist
╠➥ *${prefix}boanoite
╠➥ *${prefix}boatarde
╠➥ *${prefix}bomdia
╠➥ *${prefix}canal
╠➥ *${prefix}clone
╠➥ *${prefix}dono
╠➥ *${prefix}gtts [ OFF ]
╠➥ *${prefix}hentai
╠➥ *${prefix}hilih
╠➥ *${prefix}kick
╠➥ *${prefix}limpar
╠➥ *${prefix}linkgroup
╠➥ *${prefix}listadmins
╠➥ *${prefix}lofi
╠➥ *${prefix}loli1
╠➥ *${prefix}malkova
╠➥ *${prefix}marcar
╠➥ *${prefix}marcar2
╠➥ *${prefix}marcar3
╠➥ *${prefix}meme
╠➥ *${prefix}memeindo
╠➥ *${prefix}mia
╠➥ *${prefix}mia1
╠➥ *${prefix}mia2
╠➥ *${prefix}nsfwloli
╠➥ *${prefix}ocr
╠➥ *${prefix}porno
╠➥ *${prefix}promote
╠➥ *${prefix}reislin
╠➥ *${prefix}setprefix
╠➥ *${prefix}simi
╠➥ *${prefix}simih
╠➥ *${prefix}simih 0
╠➥ *${prefix}simih 1 
╠➥ *${prefix}sticker nobg ou stiker nobg
╠➥ *${prefix}sticker ou stiker
╠➥ *${prefix}tiktok
╠➥ *${prefix}tiktokstalk
╠➥ *${prefix}toimg
╠➥ *${prefix}ts
╠➥ *${prefix}tsticker ou tstiker      
╠➥ *${prefix}url2img [ OFF ]
╠➥ *${prefix}wait
╠➥ *${prefix}welcome 0
╠➥ *${prefix}welcome 1
╠➥ *${prefix}ytsearch
║
╠═〘 𝐒𝐔𝐏𝐎𝐑𝐓𝐄 〙
║
║  wa.me/5579999076521
║
║    KEN DOMINA 🤠🤙
║
║🐊🔥Link do chat:
║https://chat.whatsapp.com/E0bEu8MgFBxJNPNgsvtyxJ
║
╚══✪〘 𝐊𝐄𝐍 𝐁𝐎𝐓 〙`
}

exports.help1 = help1















